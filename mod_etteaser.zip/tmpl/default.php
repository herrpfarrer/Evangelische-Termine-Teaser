<?php 
// No direct access
defined('_JEXEC') or die; ?>
<?php 
JHtml::_('stylesheet', JUri::root() . 'media/mod_etteaser/css/etteaser.css');
echo $teaser; ?>